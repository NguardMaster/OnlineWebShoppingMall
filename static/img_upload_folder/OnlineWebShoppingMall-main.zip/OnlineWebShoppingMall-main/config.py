#config file

ADMIN_PASSWORD = 'hellowk09!'