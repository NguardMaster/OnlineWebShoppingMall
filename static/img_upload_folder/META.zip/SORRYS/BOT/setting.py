api = ""
api_token = ""
#문화상품권 1초 자동충전 세팅입니다. 건들지마세요.
token = ""
admin_id = "" #어드민 아이디
webhook_name = "" #웹훅이름
webhook_profile_url = "" #웹훅 프로필 사진
bot_name = "" #봇 이름
domain = "" #도메인
