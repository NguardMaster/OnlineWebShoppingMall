api = ""
api_token = ""
#문화상품권 1초 자동충전 세팅입니다. 건들지마세요.
token = "OTg3NzAyNjEwODkzMDkwODg3.Gkpvxc.JjijsfG84ZHgmdYNj6tL8PctCaZg5C9wIA1DTQ"
admin_id = "987313811843346442" #어드민 아이디
webhook_name = "Meta Vends" #웹훅이름
webhook_profile_url = "https://cdn.discordapp.com/attachments/973104817264263168/987703223857074217/Meta.png" #웹훅 프로필 사진
bot_name = "Meta Vending" #봇 이름
domain = "http://vend.buttonvend.xyz" #도메인
